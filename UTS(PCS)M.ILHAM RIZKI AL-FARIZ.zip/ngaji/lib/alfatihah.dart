import 'package:flutter/material.dart';

class alfatihah extends StatelessWidget {
  const alfatihah ({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('alfatihah'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: const <Widget>[
            Text(
              'Pembukaan',
              style: TextStyle(fontSize: 30),
            ),
            Padding(padding: EdgeInsets.only(top: 12.0)),
            Text(
              'بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِاَلْحَمْدُ لِلّٰهِ رَبِّ الْعٰلَمِيْنَالرَّحْمٰنِ الرَّحِيْمِمٰلِكِ يَوْمِ الدِّيْنِاِيَّاكَ نَعْبُدُ وَاِيَّاكَ نَسْتَعِيْنُاِھْدِنَا الصِّرَاطَ الْمُسْتَـقِيْمَصِرَاطَ الَّذِيۡنَ اَنۡعَمۡتَ عَلَيۡهِمۡ ۙ غَيۡرِ الۡمَغۡضُوۡبِ عَلَيۡهِمۡ وَلَا الضَّآلِّيۡنَ''bismillāhir-raḥmānir-raḥīm, al-ḥamdu lillāhi rabbil-‘ālamīn, ar-raḥmānir-raḥīm,māliki yaumid-dīn,iyyāka na’budu wa iyyāka nasta’īn, ihdinaṣ-ṣirāṭal-mustaqīm, ṣirāṭallażīna an’amta ‘alaihim gairil-magḍụbi ‘alaihim wa laḍ-ḍāllīn'
              '1.Dengan nama Allah Yang Maha Pengasih, Maha Penyayang. 2. Segala puji bagi Allah, Tuhan seluruh alam.3. Yang Maha Pengasih, Maha Penyayang. 4. Pemilik hari pembalasan. 5. Hanya kepada Engkaulah kami menyembah dan hanya kepada Engkaulah kami mohon pertolongan. 6. Tunjukilah kami jalan yang lurus. 7. (yaitu) jalan orang-orang yang telah Engkau beri nikmat kepadanya; bukan (jalan) mereka yang dimurkai, dan bukan (pula jalan) mereka yang sesat. ',
              style: TextStyle(fontSize: 20.0),
            ),
          ],
        ),
      ),
    );
  }
}
