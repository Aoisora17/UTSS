import 'package:flutter/material.dart';

class annas extends StatelessWidget {
  const annas({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('An Naas'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: const <Widget>[
            Text(
              'Umat Manusia',
              style: TextStyle(fontSize: 30),
            ),
            Padding(padding: EdgeInsets.only(top: 12.0)),
            Text(
              'بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِقُلْ اَعُوْذُ بِرَبِّ النَّاسِمَلِكِ النَّاسِۙاِلٰهِ النَّاسِۙمِنۡ شَرِّ الۡوَسۡوَاسِ  ۙ الۡخَـنَّاسِالَّذِىۡ يُوَسۡوِسُ فِىۡ صُدُوۡرِ النَّاسِۙمِنَ الۡجِنَّةِ وَالنَّاسِ''bissmillah hirohman nirohim, Qul auzu birabbin naas, Malikinas, ilahinas, minsyahril was wasil khonas, Al lazii yuwas wisu fii suduurin naasMinal jinnati wan naas''1. Katakanlah, "Aku berlindung kepada Tuhannya manusia. 2. Raja Manusia. 3.Sembahan manusia. 4. dari kejahatan (bisikan) setan yang bersembunyi. 5. yang membisikkan (kejahatan) ke dalam dada manusia. 6. dari (golongan) jin dan manusia.',
              style: TextStyle(fontSize: 20.0),
            ),
          ],
        ),
      ),
    );
  }
}
