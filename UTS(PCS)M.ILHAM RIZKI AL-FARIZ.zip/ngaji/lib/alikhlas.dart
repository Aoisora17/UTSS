import 'package:flutter/material.dart';

class alikhlas extends StatelessWidget {
  const alikhlas({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Al Ikhlas'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: const <Widget>[
            Text(
              'Ikhlas',
              style: TextStyle(fontSize: 30),
            ),
            Padding(padding: EdgeInsets.only(top: 12.0)),
            Text(
              'بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِقُلۡ هُوَ اللّٰهُ اَحَدٌ‌اَللّٰهُ الصَّمَدُ‌لَمۡ يَلِدۡ ۙ وَلَمۡ يُوۡلَدۡوَلَمۡ يَكُنۡ لَّهٗ كُفُوًا اَحَدٌ''Qul huwal laahu ahad, Allah hus-samad,Lam yalid wa lam yuulad,Wa lam yakul-lahu kufuwan ahad''Katakanlah (Muhammad), "Dialah Allah, Yang Maha Esa.Allah tempat meminta segala sesuatu.(Allah) tidak beranak dan tidak pula diperanakkan.Dan tidak ada sesuatu yang setara dengan Dia."',
              style: TextStyle(fontSize: 20.0),
            ),
          ],
        ),
      ),
    );
  }
}
