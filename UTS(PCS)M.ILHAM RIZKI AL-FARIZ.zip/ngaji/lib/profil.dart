import 'package:flutter/material.dart';

class Profil extends StatelessWidget {
  const Profil({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      appBar: AppBar(
        title: const Text('about'),
      ),
      body: ListView(
        children: [
          Container(
            padding: EdgeInsets.only(top: 16.0),
            child: Column(
              children: [
                Text(
                  'aplikasi mempermudahkan kalian untuk mengaji',
                  style: TextStyle(fontSize: 25.0),
                ),
                Padding(padding: EdgeInsets.only(top: 16.0, bottom: 16.0)),
                Text('mudah dipahami'),
                Padding(padding: EdgeInsets.only(top: 16.0, bottom: 16.0)),
                Text('2.ada aksara arab'),
                Padding(padding: EdgeInsets.only(top: 16.0, bottom: 16.0)),
                Text('ada aksara latin'),
                Padding(padding: EdgeInsets.only(top: 16.0, bottom: 16.0)),
                Text('ada artinya')
              ],
            ),
          )
        ],
      ),
    );
  }
}
